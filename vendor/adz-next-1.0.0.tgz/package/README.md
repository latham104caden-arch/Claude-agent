# @adz/next — adz. kit for Vercel / Next.js sites

Connects a Next.js site on Vercel to adz. You get the same things Shopify and
WooCommerce stores get:

- **Creator links on your own domain:** `yoursite.com/r/HUNTER` logs the click,
  remembers the creator for 30 days, and sends the shopper to your landing page.
- **Channel links:** `yoursite.com/tt` and `yoursite.com/ig` for social bios.
- **Live creator codes:** codes you create, edit, pause or expire in adz work at
  your checkout within a minute. You don't copy anything by hand.
- **Order + refund tracking:** paid orders create creator commissions, and
  refunds claw them back, through the same adz ledger as Shopify and Woo.

Requires Next.js 13.4+ (App or Pages Router) and Node 20+. No dependencies.

## 1. Install

```bash
npm install https://useadz.com/vercel-kit/adz-next-1.0.0.tgz
```

Or download `adz-next.zip`, unzip it into your repo root, and run
`npm install ./adz-next`. Imports are the same (`@adz/next`) either way.

## 2. Environment variables

In Vercel, go to **Project → Settings → Environment Variables** and add these
for Production (and Preview if you test there). Copy the values from
adz → Connections → Vercel.

| Name | Value |
|---|---|
| `ADZ_INTEGRATION_ID` | your integration id |
| `ADZ_SECRET` | your secret (mark it **Sensitive**) |

Never prefix them with `NEXT_PUBLIC_`. The secret must stay on the server.

## 3. Middleware (links + cookies)

`middleware.js` at the project root (or `src/middleware.js`):

```js
import { adzMiddleware } from '@adz/next/middleware';

export async function middleware(request) {
  const adz = await adzMiddleware(request);
  if (adz) return adz;
  // ...your existing middleware, if any
}

export const config = { matcher: ['/((?!api/|_next/|.*\\..*).*)'] };
```

## 4. Install check route

App Router, `app/api/adz/health/route.js`:

```js
export { GET, POST } from '@adz/next/health';
```

Pages Router, `pages/api/adz/health.js`:

```js
export { pagesHandler as default } from '@adz/next/health';
```

## 5. Apply creator codes at checkout

```js
import { cookies } from 'next/headers';
import { validateCode, readAttribution } from '@adz/next';

const { code: fromLink } = readAttribution(await cookies());
const check = await validateCode(typedCode || fromLink);
// → { valid: true, code: 'HUNTER', discount_pct: 15, kind: 'standard', ... }
if (check.valid) applyPercentOff(check.discount_pct);
```

Save `readAttribution()` (or `attributionMetadata()`) with the order, for
example in Stripe session metadata. The code that reports the order often runs
in a webhook, where the shopper's cookies aren't available.

## 6. Report orders and refunds

Call these from wherever you learn an order is **paid** (a payment webhook, an
order-created handler, and so on). Amounts are in major units (`49.99`).

```js
import { trackOrder, trackRefund, trackCancel } from '@adz/next';

await trackOrder({
  id: 'ord_123',            // your order / payment id (dedupe key)
  total: 54.12,             // what the customer paid
  subtotal: 44.99,          // goods after discounts, before tax + shipping
  shipping: 5, tax: 4.13, currency: 'USD',
  code: 'HUNTER',           // discount code used (if any)
  referral: 'HUNTER',       // creator from the link cookie (if any)
  source: 'tiktok',         // channel cookie (optional)
  customer: { email: 'ana@example.com', firstName: 'Ana' },
  lineItems: [{ sku: 'SERUM-1', name: 'Serum', quantity: 1, price: 44.99 }],
});

await trackRefund({ orderId: 'ord_123', amount: 20, refundId: 're_1' });
await trackRefund({ orderId: 'ord_123', totalRefunded: 54.12 }); // cumulative form
await trackCancel({ orderId: 'ord_123' });
```

`examples/` has a complete Stripe Checkout setup (`app/api/checkout` and
`app/api/stripe-webhook`).

## 7. Deploy and verify

Redeploy on Vercel so the env vars load. Then in adz → Connections, click
**Test** on the Vercel row. It turns **Active** once adz reaches
`yoursite.com/api/adz/health` and the keys match.

## Troubleshooting

- **Test says "kit not found":** the health route isn't deployed at
  `/api/adz/health`, or the site URL in adz is wrong.
- **Test says "not configured":** env vars are missing, or you haven't
  redeployed since adding them.
- **Test says "keys don't match":** `ADZ_SECRET` isn't the current secret shown
  in adz.
- **Orders don't show up:** `trackOrder` throws an `AdzError` with the reason.
  Log it from your webhook.
