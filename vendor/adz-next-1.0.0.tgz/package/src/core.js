// adz kit — shared config + signed transport.
//
// Everything talks to adz over HMAC-SHA256-signed JSON POSTs, using the
// integration's secret from the brand's Vercel env vars. Web Crypto only, so
// the same code runs in the Edge runtime (middleware) and Node (route
// handlers, webhooks). No dependencies.

export const KIT_VERSION = '1.0.0';

const DEFAULT_API_URL = 'https://useadz.com';

// Env vars are referenced statically (process.env.NAME, never process.env[x])
// so Next.js can resolve them in Edge bundles.
function readEnv() {
  try {
    return {
      integrationId: process.env.ADZ_INTEGRATION_ID,
      secret: process.env.ADZ_SECRET,
      apiUrl: process.env.ADZ_API_URL,
    };
  } catch {
    return {};
  }
}

export function getConfig(overrides = {}) {
  const env = readEnv();
  const integrationId = String(overrides.integrationId || env.integrationId || '').trim();
  const secret = String(overrides.secret || env.secret || '').trim();
  const apiUrl = String(overrides.apiUrl || env.apiUrl || DEFAULT_API_URL).trim().replace(/\/+$/, '');
  return { integrationId, secret, apiUrl, configured: Boolean(integrationId && secret) };
}

function subtle() {
  const s = globalThis.crypto && globalThis.crypto.subtle;
  if (!s) throw new Error('[adz] Web Crypto is unavailable — use Node 20+ or the Edge runtime.');
  return s;
}

export async function hmacHex(secret, message) {
  const enc = new TextEncoder();
  const key = await subtle().importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await subtle().sign('HMAC', key, enc.encode(message));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Constant-time-ish compare for hex strings of equal length.
export function safeEqual(a, b) {
  const x = String(a || '');
  const y = String(b || '');
  if (x.length !== y.length || x.length === 0) return false;
  let diff = 0;
  for (let i = 0; i < x.length; i += 1) diff |= x.charCodeAt(i) ^ y.charCodeAt(i);
  return diff === 0;
}

export class AdzError extends Error {
  constructor(message, { status, code } = {}) {
    super(message);
    this.name = 'AdzError';
    this.status = status || null;
    this.code = code || null;
  }
}

// POST a signed JSON body to /api/integrations/vercel/<integration>/<action>.
export async function signedPost(action, payload, options = {}) {
  const cfg = getConfig(options);
  if (!cfg.configured) {
    throw new AdzError('[adz] ADZ_INTEGRATION_ID and ADZ_SECRET must be set (Vercel → Settings → Environment Variables).', { code: 'not_configured' });
  }
  const body = JSON.stringify({ ...payload, sent_at: new Date().toISOString() });
  const signature = await hmacHex(cfg.secret, body);
  const url = `${cfg.apiUrl}/api/integrations/vercel/${encodeURIComponent(cfg.integrationId)}/${action}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs || 8000);
  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-adz-signature': signature,
        'x-adz-kit-version': KIT_VERSION,
      },
      body,
      signal: controller.signal,
      cache: 'no-store',
    });
  } catch (err) {
    throw new AdzError(`[adz] ${action} request failed: ${err?.message || err}`, { code: 'network' });
  } finally {
    clearTimeout(timer);
  }

  let json = null;
  try { json = await res.json(); } catch { json = null; }
  if (!res.ok || (json && json.ok === false && res.status >= 400)) {
    throw new AdzError(`[adz] ${action} rejected (${res.status}): ${json?.error || 'unknown_error'}`, {
      status: res.status,
      code: json?.error || null,
    });
  }
  return json || { ok: true };
}

// ── cookies ────────────────────────────────────────────────────────────
// Neutral names (no "adz") — same as the WordPress plugin, since customers
// can see cookie names in DevTools.
export const REF_COOKIE = '_aff';
export const SRC_COOKIE = '_src';
export const COOKIE_TTL_DAYS = 30;

export const CODE_PATTERN = /^[A-Za-z0-9-]{1,64}$/;
