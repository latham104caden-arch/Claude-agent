// adz kit — Next.js middleware. Import from '@adz/next/middleware'.
//
// Handles, on the brand's own domain (customers never see useadz.com):
//   /r/<CODE>          creator link → log click, set 30-day referral cookie,
//                      redirect to the landing page chosen in adz (default /)
//   /tt, /ig           channel links for social bios → set source cookie, go home
//   ?adz_coupon=<CODE> deep link → set referral cookie, strip the param
//
// Returns a Response for those paths and undefined for everything else, so it
// composes with any middleware you already have:
//
//   import { adzMiddleware } from '@adz/next/middleware';
//   export async function middleware(request) {
//     const adz = await adzMiddleware(request);
//     if (adz) return adz;
//     // ...your existing middleware
//   }
//   export const config = { matcher: ['/((?!api/|_next/|.*\\..*).*)'] };

import { CODE_PATTERN, COOKIE_TTL_DAYS, REF_COOKIE, SRC_COOKIE } from './core.js';
import { trackClick } from './server.js';

const CHANNELS = { tt: 'tiktok', ig: 'instagram' };

function cookieHeader(name, value, secure) {
  const maxAge = COOKIE_TTL_DAYS * 86400;
  return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${maxAge}; SameSite=Lax${secure ? '; Secure' : ''}`;
}

function redirect(location, cookies) {
  const headers = new Headers({ location: location.toString(), 'cache-control': 'no-store' });
  for (const c of cookies) headers.append('set-cookie', c);
  return new Response(null, { status: 307, headers });
}

// Only follow same-site relative paths from adz ("/products"), never "//evil".
function safePath(p) {
  const s = String(p || '');
  return s.startsWith('/') && !s.startsWith('//') ? s : '/';
}

function clientIp(request) {
  const fwd = request.headers.get('x-forwarded-for');
  if (fwd) return fwd.split(',')[0].trim();
  return request.headers.get('x-real-ip') || request.ip || null;
}

export async function adzMiddleware(request, options = {}) {
  const url = new URL(request.url);
  const secure = url.protocol === 'https:';
  const prefix = String(options.prefix || 'r').replace(/^\/+|\/+$/g, '');
  const path = url.pathname.replace(/\/+$/, '') || '/';

  // /tt, /ig — channel attribution for bio links.
  const channel = CHANNELS[path.slice(1).toLowerCase()];
  if (channel && options.channelLinks !== false) {
    return redirect(new URL('/', url), [cookieHeader(SRC_COOKIE, channel, secure)]);
  }

  // /r/<CODE> — creator affiliate link.
  const prefixPath = `/${prefix}/`;
  if (path.toLowerCase().startsWith(prefixPath.toLowerCase())) {
    const code = decodeURIComponent(path.slice(prefixPath.length));
    if (!CODE_PATTERN.test(code)) return redirect(new URL('/', url), []);

    let destination = '/';
    let known = true;
    try {
      const res = await trackClick({
        code,
        ip: clientIp(request),
        userAgent: request.headers.get('user-agent'),
        referrer: request.headers.get('referer'),
      }, options);
      if (res && res.found === false) known = false;
      if (res && res.redirect_path) destination = safePath(res.redirect_path);
    } catch (err) {
      // adz unreachable: still set the cookie and send the shopper on — the
      // code is re-validated at checkout, so nothing bogus gets applied.
      if (options.debug) console.warn('[adz] click beacon failed', err?.message || err);
    }

    const target = new URL(destination, url);
    // Carry any UTM params through to the landing page.
    url.searchParams.forEach((v, k) => { if (!target.searchParams.has(k)) target.searchParams.set(k, v); });
    const cookies = known ? [cookieHeader(REF_COOKIE, code.toUpperCase(), secure)] : [];
    return redirect(target, cookies);
  }

  // ?adz_coupon=<CODE> — deep link straight to a page with the code staged.
  const couponParam = url.searchParams.get('adz_coupon');
  if (couponParam !== null) {
    url.searchParams.delete('adz_coupon');
    const cookies = CODE_PATTERN.test(couponParam) ? [cookieHeader(REF_COOKIE, couponParam.toUpperCase(), secure)] : [];
    return redirect(url, cookies);
  }

  return undefined;
}

export default adzMiddleware;
