// adz kit — install check route. adz calls this to confirm the kit is deployed
// and the env vars are right (the "Test" button in adz → Connections).
//
// App Router:   app/api/adz/health/route.js
//   export { GET, POST } from '@adz/next/health';
//
// Pages Router: pages/api/adz/health.js
//   export { pagesHandler as default } from '@adz/next/health';

import { KIT_VERSION, getConfig, hmacHex, safeEqual } from './core.js';

export const dynamic = 'force-dynamic';

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  });
}

// Public: says the kit exists and whether keys are set. Never leaks secrets.
export async function GET() {
  const cfg = getConfig();
  return json({ ok: true, kit: 'adz-next', version: KIT_VERSION, configured: cfg.configured });
}

// Signed challenge from adz. We answer with HMAC(secret, nonce) — proves this
// deployment holds the same secret adz issued, without ever sending it.
async function answerChallenge(rawBody, signature) {
  const cfg = getConfig();
  if (!cfg.configured) return { status: 503, body: { ok: false, error: 'not_configured', version: KIT_VERSION } };
  const expected = await hmacHex(cfg.secret, rawBody);
  if (!safeEqual(expected, signature)) {
    return { status: 401, body: { ok: false, error: 'bad_signature', version: KIT_VERSION } };
  }
  let nonce = '';
  try { nonce = String(JSON.parse(rawBody).nonce || ''); } catch { nonce = ''; }
  if (!nonce) return { status: 400, body: { ok: false, error: 'missing_nonce' } };
  return {
    status: 200,
    body: {
      ok: true,
      kit: 'adz-next',
      version: KIT_VERSION,
      integration_id: cfg.integrationId,
      proof: await hmacHex(cfg.secret, `proof:${nonce}`),
    },
  };
}

export async function POST(request) {
  const raw = await request.text();
  const out = await answerChallenge(raw, request.headers.get('x-adz-signature'));
  return json(out.body, out.status);
}

// Pages Router variant. Reads the raw body itself (bodyParser must be off).
export async function pagesHandler(req, res) {
  if (req.method === 'GET') {
    const cfg = getConfig();
    return res.status(200).json({ ok: true, kit: 'adz-next', version: KIT_VERSION, configured: cfg.configured });
  }
  if (req.method !== 'POST') return res.status(405).json({ ok: false });
  let raw;
  if (req.body !== undefined && req.body !== null) {
    // Next's default bodyParser already consumed the stream. adz signs compact
    // JSON, so re-serializing the parsed object reproduces the signed bytes.
    raw = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
  } else {
    const chunks = [];
    for await (const chunk of req) chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
    raw = Buffer.concat(chunks).toString('utf8');
  }
  const out = await answerChallenge(raw, req.headers['x-adz-signature']);
  return res.status(out.status).json(out.body);
}

export const pagesConfig = { api: { bodyParser: false } };
