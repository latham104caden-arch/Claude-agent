// adz kit — server helpers. Import from '@adz/next'.
//
//   validateCode(code)            → is this a live creator code, and what % off?
//   readAttribution(cookies)      → { code, source } from the shopper's cookies
//   trackOrder(order)             → report a PAID order (idempotent on order.id)
//   trackRefund({ orderId, amount })
//   trackCancel({ orderId })
//
// Call these from server code only (route handlers, server actions, webhooks).
// They sign requests with ADZ_SECRET, which must never reach the browser.

import {
  AdzError,
  CODE_PATTERN,
  KIT_VERSION,
  REF_COOKIE,
  SRC_COOKIE,
  getConfig,
  signedPost,
} from './core.js';

export { AdzError, KIT_VERSION, getConfig };

// ── attribution cookies ───────────────────────────────────────────────

function parseCookieHeader(header) {
  const out = {};
  String(header || '').split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i < 0) return;
    const k = part.slice(0, i).trim();
    if (!k) return;
    try { out[k] = decodeURIComponent(part.slice(i + 1).trim()); } catch { out[k] = part.slice(i + 1).trim(); }
  });
  return out;
}

function cookieValue(source, name) {
  if (!source) return null;
  // next/headers cookies() store, NextRequest.cookies
  if (typeof source.get === 'function' && !(source instanceof Headers)) {
    const v = source.get(name);
    if (v && typeof v === 'object') return v.value ?? null;
    if (typeof v === 'string') return v;
  }
  // Request / NextRequest
  if (source.headers && typeof source.headers.get === 'function') {
    return parseCookieHeader(source.headers.get('cookie'))[name] ?? null;
  }
  // Headers
  if (source instanceof Headers) return parseCookieHeader(source.get('cookie'))[name] ?? null;
  // Pages Router / Node IncomingMessage (plain headers object)
  if (source.headers && typeof source.headers === 'object' && source.headers.cookie) {
    return parseCookieHeader(source.headers.cookie)[name] ?? null;
  }
  // Pages Router req.cookies object
  if (typeof source === 'object' && source[name] !== undefined) return source[name];
  // Raw "a=b; c=d" header string
  if (typeof source === 'string') return parseCookieHeader(source)[name] ?? null;
  return null;
}

// Returns the creator code + channel the shopper arrived with (30-day cookies
// set by the adz middleware). Pass whatever you have: cookies() from
// next/headers, a Request, Headers, req.cookies, or a raw cookie header.
export function readAttribution(source) {
  const rawCode = cookieValue(source, REF_COOKIE);
  const code = rawCode && CODE_PATTERN.test(rawCode) ? rawCode.toUpperCase() : null;
  const rawSrc = cookieValue(source, SRC_COOKIE);
  const channel = rawSrc === 'tiktok' || rawSrc === 'instagram' ? rawSrc : null;
  return { code, source: channel };
}

// Flatten attribution into string metadata for Stripe Checkout / PaymentIntents
// so the webhook that later calls trackOrder() still knows who referred it.
export function attributionMetadata(source) {
  const a = readAttribution(source);
  const meta = {};
  if (a.code) meta.adz_ref = a.code;
  if (a.source) meta.adz_src = a.source;
  return meta;
}

// ── code checks ──────────────────────────────────────────────────────

const CODE_CACHE_TTL_MS = 60_000;
const codeCache = new Map();

// { valid, code, discount_pct, kind, bogo_rule, expires_at, reason }
// Cached for 60s per code. Edits in adz (rate, pause, expiry) apply within a minute.
export async function validateCode(code, options = {}) {
  const raw = String(code || '').trim();
  if (!raw || !CODE_PATTERN.test(raw)) {
    return { valid: false, code: raw.toUpperCase() || null, reason: 'invalid_format' };
  }
  const key = raw.toUpperCase();
  const hit = codeCache.get(key);
  if (!options.fresh && hit && Date.now() - hit.at < CODE_CACHE_TTL_MS) return hit.value;

  const res = await signedPost('code', { code: key }, { ...options, timeoutMs: options.timeoutMs || 4000 });
  const value = {
    valid: Boolean(res.valid),
    code: res.code || key,
    discount_pct: res.discount_pct == null ? null : Number(res.discount_pct),
    kind: res.kind || null,
    bogo_rule: res.bogo_rule || null,
    expires_at: res.expires_at || null,
    reason: res.reason || null,
  };
  codeCache.set(key, { at: Date.now(), value });
  return value;
}

// Logged by the middleware on every /r/<code> hit. Exposed for custom routing.
export async function trackClick({ code, ip, userAgent, referrer } = {}, options = {}) {
  return signedPost('click', {
    code: String(code || '').toUpperCase(),
    ip: ip || null,
    user_agent: userAgent ? String(userAgent).slice(0, 500) : null,
    referrer: referrer ? String(referrer).slice(0, 500) : null,
  }, { ...options, timeoutMs: options.timeoutMs || 2500 });
}

// ── orders ───────────────────────────────────────────────────────────

function num(v, field) {
  if (v === undefined || v === null || v === '') return null;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new AdzError(`[adz] order.${field} must be a number (got ${v})`, { code: 'invalid_order' });
  return n;
}

function normalizeCodes(order) {
  const list = [];
  if (Array.isArray(order.codes)) list.push(...order.codes);
  if (order.code) list.push(order.code);
  if (Array.isArray(order.discountCodes)) list.push(...order.discountCodes);
  return [...new Set(list.map((c) => String(c || '').trim().toUpperCase()).filter(Boolean))];
}

function normalizeOrder(order) {
  if (!order || order.id === undefined || order.id === null || String(order.id).trim() === '') {
    throw new AdzError('[adz] order.id is required', { code: 'invalid_order' });
  }
  const total = num(order.total, 'total');
  if (total === null) throw new AdzError('[adz] order.total is required', { code: 'invalid_order' });
  const customer = order.customer || {};
  const lineItems = Array.isArray(order.lineItems || order.line_items) ? (order.lineItems || order.line_items) : [];
  return {
    id: String(order.id),
    number: order.number != null ? String(order.number) : null,
    status: order.status ? String(order.status).toLowerCase() : 'paid',
    currency: String(order.currency || 'USD').toUpperCase(),
    total,
    subtotal: num(order.subtotal, 'subtotal'),
    shipping: num(order.shipping, 'shipping') ?? 0,
    tax: num(order.tax, 'tax') ?? 0,
    discount: num(order.discount, 'discount') ?? 0,
    discount_codes: normalizeCodes(order),
    referral_code: order.referral ? String(order.referral).trim().toUpperCase() : null,
    source: order.source === 'tiktok' || order.source === 'instagram' ? order.source : null,
    customer: {
      id: customer.id != null ? String(customer.id) : null,
      email: customer.email || order.email || null,
      first_name: customer.firstName || customer.first_name || null,
      last_name: customer.lastName || customer.last_name || null,
    },
    created_at: order.createdAt || order.created_at
      ? new Date(order.createdAt || order.created_at).toISOString()
      : new Date().toISOString(),
    line_items: lineItems.map((li) => ({
      sku: li.sku || null,
      name: li.name || li.title || null,
      quantity: num(li.quantity ?? li.qty ?? 1, 'lineItems[].quantity') ?? 1,
      price: num(li.price ?? li.unitPrice ?? li.unit_price, 'lineItems[].price') ?? 0,
      subtotal: num(li.subtotal ?? li.total, 'lineItems[].subtotal'),
    })),
  };
}

// Report a PAID order. Safe to call more than once for the same order id —
// adz dedupes. Amounts are in major units (49.99, not 4999).
//
//   await trackOrder({
//     id: 'ord_123', number: '1042', total: 54.12, subtotal: 44.99,
//     shipping: 5, tax: 4.13, currency: 'USD',
//     code: 'HUNTER',               // discount code(s) used at checkout
//     referral: 'HUNTER',           // from readAttribution() / session metadata
//     source: 'tiktok',             // optional channel from readAttribution()
//     customer: { email: 'a@b.com', firstName: 'Ana' },
//     lineItems: [{ sku: 'SERUM-1', name: 'Serum', quantity: 1, price: 44.99 }],
//   });
export async function trackOrder(order, options = {}) {
  const normalized = normalizeOrder(order);
  return signedPost('events', { type: 'order.paid', order: normalized }, options);
}

// Report a refund (full or partial). Two ways:
//   { orderId, amount, refundId }   — one refund of `amount`. Pass refundId so
//                                     a retried webhook can't count it twice.
//   { orderId, totalRefunded }      — the order's cumulative refunded amount
//                                     (e.g. Stripe charge.amount_refunded).
//                                     adz applies only the difference.
export async function trackRefund({ orderId, amount, totalRefunded, refundId, reason } = {}, options = {}) {
  if (!orderId) throw new AdzError('[adz] trackRefund requires orderId', { code: 'invalid_refund' });
  const value = num(amount, 'amount');
  const cumulative = num(totalRefunded, 'totalRefunded');
  if (!(value > 0) && !(cumulative > 0)) {
    throw new AdzError('[adz] trackRefund requires a positive amount or totalRefunded', { code: 'invalid_refund' });
  }
  return signedPost('events', {
    type: 'order.refunded',
    order: { id: String(orderId) },
    refund: {
      id: refundId ? String(refundId) : null,
      amount: value > 0 ? value : null,
      total_refunded: cumulative > 0 ? cumulative : null,
      reason: reason ? String(reason).slice(0, 500) : null,
    },
  }, options);
}

// Report a cancelled / voided order (treated as a full refund).
export async function trackCancel({ orderId, reason } = {}, options = {}) {
  if (!orderId) throw new AdzError('[adz] trackCancel requires orderId', { code: 'invalid_cancel' });
  return signedPost('events', {
    type: 'order.cancelled',
    order: { id: String(orderId) },
    refund: { reason: reason ? String(reason).slice(0, 500) : null },
  }, options);
}

export default {
  validateCode,
  readAttribution,
  attributionMetadata,
  trackClick,
  trackOrder,
  trackRefund,
  trackCancel,
};
