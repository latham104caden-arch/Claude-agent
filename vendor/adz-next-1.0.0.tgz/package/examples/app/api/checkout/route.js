// app/api/checkout/route.js — example: Stripe Checkout with adz creator codes.
//
// 1. Uses the code the shopper typed, or the one from their creator link.
// 2. Asks adz whether it's a live creator code and how much it takes off.
// 3. Stores attribution on the session so the webhook can report the order.
import Stripe from 'stripe';
import { cookies } from 'next/headers';
import { validateCode, readAttribution, attributionMetadata } from '@adz/next';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function POST(request) {
  const { items, code: typedCode } = await request.json();
  const jar = await cookies();
  const attribution = readAttribution(jar);

  const code = typedCode || attribution.code;
  const discounts = [];
  const metadata = attributionMetadata(jar);

  if (code) {
    const check = await validateCode(code);
    if (check.valid && check.discount_pct > 0) {
      const coupon = await stripe.coupons.create({
        percent_off: check.discount_pct,
        duration: 'once',
        max_redemptions: 1,
        name: check.code,
      });
      discounts.push({ coupon: coupon.id });
      metadata.adz_code = check.code;
    }
  }

  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    line_items: items, // [{ price: 'price_…', quantity: 1 }]
    discounts,
    metadata,
    payment_intent_data: { metadata },
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/thanks`,
    cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/cart`,
  });
  return Response.json({ url: session.url });
}
