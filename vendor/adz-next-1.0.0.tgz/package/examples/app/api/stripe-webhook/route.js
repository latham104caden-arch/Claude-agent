// app/api/stripe-webhook/route.js — example: report paid + refunded orders.
//
// Stripe → Developers → Webhooks → add this URL with events:
//   checkout.session.completed, charge.refunded
import Stripe from 'stripe';
import { trackOrder, trackRefund } from '@adz/next';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function POST(request) {
  const body = await request.text();
  let event;
  try {
    event = stripe.webhooks.constructEvent(body, request.headers.get('stripe-signature'), process.env.STRIPE_WEBHOOK_SECRET);
  } catch {
    return new Response('bad signature', { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = await stripe.checkout.sessions.retrieve(event.data.object.id, { expand: ['line_items'] });
    if (session.payment_status === 'paid') {
      const d = session.total_details || {};
      await trackOrder({
        id: session.payment_intent || session.id, // same id you'll refund against
        number: session.id.slice(-8),
        total: session.amount_total / 100,
        subtotal: (session.amount_subtotal - (d.amount_discount || 0)) / 100,
        shipping: (d.amount_shipping || 0) / 100,
        tax: (d.amount_tax || 0) / 100,
        currency: session.currency,
        code: session.metadata?.adz_code,
        referral: session.metadata?.adz_ref,
        source: session.metadata?.adz_src,
        customer: { email: session.customer_details?.email, firstName: session.customer_details?.name },
        lineItems: (session.line_items?.data || []).map((li) => ({
          sku: li.price?.lookup_key || li.price?.product,
          name: li.description,
          quantity: li.quantity,
          price: li.price?.unit_amount / 100,
        })),
      });
    }
  }

  if (event.type === 'charge.refunded') {
    const charge = event.data.object;
    await trackRefund({ orderId: charge.payment_intent, totalRefunded: charge.amount_refunded / 100 });
  }

  return Response.json({ received: true });
}
