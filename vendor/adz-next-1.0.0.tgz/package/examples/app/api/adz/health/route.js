// app/api/adz/health/route.js — lets adz verify the install ("Test" button).
export { GET, POST } from '@adz/next/health';
