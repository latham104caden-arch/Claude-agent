// middleware.js (project root, or src/middleware.js if you use /src)
//
// Already have a middleware? Keep it — call adzMiddleware first and return its
// response when it gives one.
import { adzMiddleware } from '@adz/next/middleware';

export async function middleware(request) {
  const adz = await adzMiddleware(request);
  if (adz) return adz;
  // ...your existing middleware logic (or nothing)
}

export const config = {
  // Every page except API routes, Next internals, and static files.
  matcher: ['/((?!api/|_next/|.*\\..*).*)'],
};
