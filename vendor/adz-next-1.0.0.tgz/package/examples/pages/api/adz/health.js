// pages/api/adz/health.js — Pages Router version of the install check.
export { pagesHandler as default } from '@adz/next/health';
